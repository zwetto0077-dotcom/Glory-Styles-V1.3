Glory Styles - Fabric-Mod für Minecraft 1.21.11
===========================================

SO BAUST DU DIE MOD
1. Auf https://fabricmc.net/develop die Vorlage für 1.21.11 (Yarn, Java 21) erzeugen
   und entpacken - die enthält den Gradle-Wrapper.
2. In dieser Vorlage den Ordner "src" durch den "src" aus diesem Projekt ersetzen.
3. Die Versionen in gradle.properties / build.gradle der Vorlage behalten
   (meine Werte hier sind nur Richtwerte).
4. Bauen: ./gradlew build  ->  build/libs/zwettos-textures-1.0.0.jar
   (Windows: gradlew.bat build)
5. Jar in den mods-Ordner (NoRisk-Client: Modpaket -> Mods) legen. Fabric API wird benötigt.

BEREICHE (Sidebar links)
- Glory Clan: Info und Discord-Link (Buttons "Discord öffnen" und "Link kopieren").
- Allgemeine Texturen: fünf Regler, die sofort im Spiel wirken (gespeichert in config/glorystyles.json):
  * Crystal Glow 0-100 %: End-Kristalle leuchten (0 = aus, 100 = volle Helligkeit)
  * Item size 1-150 %: Größe der Items in der Hand (100 = Vanilla)
  * Partikel 0-100 %: Durchsichtigkeit der Partikel (0 = unsichtbar, 100 = Vanilla)
  * Game Brightness 1-150 %: Helligkeit der Welt ohne GUI und Items (100 = Vanilla)
  * Low Shield 1-100 %: Schild hängt tiefer (Ego-Perspektive, 100 = Vanilla, 1 = fast unsichtbar)
  * 3D Crystals (An/Aus-Schalter): End-Kristall-Item wird als 3D-Modell wie der platzierte Kristall gezeigt.
    Das Modell kommt über das Ressourcenpaket (Vorlage: assets/glorystyles/crystal_3d_item.json), das Spiel lädt kurz neu.
  Diese Regler benutzen Mixins (src/main/java/de/glorystyles/mixin). Sie sind mit require=0 abgesichert:
  passt eine Stelle nicht zu deiner Version, wird die Funktion übersprungen statt abzustürzen.
- Textures: alle Kategorien (Perlen, Crystals, Mace, Glint, Obsidian, Totem ...) wie bisher.

BEDIENUNG
- Klick auf eine Textur markiert sie mit einem orangen Punkt (nochmal klicken hebt die Markierung auf).
  Oben erscheint der Button "Anwenden (n)": ein Klick lädt alle markierten Texturen und Reglerwerte
  (auch aus mehreren Kategorien) auf einmal. Blau = gerade aktiv, orange = markiert.
- Taste J öffnet das Menü (änderbar unter Steuerung -> Glory Styles).
- Links Kategorie wählen, rechts Textur anklicken. Danach lädt das Spiel kurz die Ressourcen neu.
- "Standard" setzt die normale Minecraft-Textur zurück.

EIGENE TEXTUREN HINZUFÜGEN
1. PNG (16x16) nach src/main/resources/assets/glorystyles/textures/skins/<kategorie>/<name>.png
   (hat die Kategorie mehrere Ziele, z. B. Crystal, zusätzlich <name>_entity.png)
2. In src/main/resources/assets/glorystyles/skins.json den Namen (ohne .png) bei "skins" eintragen.

NEUES CRYSTAL-DESIGN (Unterkategorie)
1. Ordner src/main/resources/assets/glorystyles/textures/skins/crystal/<design>/ anlegen, darin
   <farbe>.png (Item) und <farbe>_entity.png (Crystal in der Welt).
2. In skins.json bei "crystal" unter "groups" einen Eintrag mit id (= Ordnername), name und den Farben ergänzen.
   Jede Kategorie kann so Unterkategorien bekommen: statt "skins" nutzt man "groups".

REGLER (Sättigung / Helligkeit)
- Rechts unter der Vorschau gibt es pro Kategorie zwei Regler (50 % = normal ist 100 %, Bereich 0-200 %).
  Die Vorschau ändert sich sofort; im Spiel gilt der Wert nach "Anwenden".
  "Zurücksetzen" stellt beide auf 100 %. Die Werte stehen in config/glorystyles.json.

AUSSEHEN
- Das Menü zeichnet alle Formen selbst in echten Bildschirm-Pixeln (glatte Rundungen, unabhängig von der
  GUI-Skalierung). Stil wie OneConfig: dunkles Panel, links Kategorien, oben Chips für die
  Designs, Karten mit blauem Namensbalken, rechts die Vorschau. Farben stehen oben in GloryStylesScreen.java.
- Mausrad blättert, wenn es mehr Karten als Platz gibt.

VANILLA-ICONS
- In der Sidebar und bei "Standard" zeigt das Menü das Original-Item (z. B. ender_pearl.png). Es wird zur
  Laufzeit aus dem Spiel geladen (VanillaTextures.java), egal welche Textur gerade aktiv ist.
  Das Icon steht pro Kategorie als "icon" in skins.json.

VORSCHAU
- Rechts im Menü zeigt eine Vorschau die Textur groß (beim Überfahren mit der Maus). Bei Glints
  steht dort ein Spieler mit verzauberter Diamant-Rüstung, der den aktuell gewählten Glint zeigt
  (er aktualisiert sich nach dem Klick, weil das Spiel dann die Ressourcen neu lädt).
- In skins.json steuert "preview" pro Kategorie die Vorschau: "item" (Standard) oder "player".

OBSIDIAN
- Kategorie "Obsidian" ersetzt obsidian.png, Kategorie "Crying Obsidian" ersetzt crying_obsidian.png
  (jeweils <farbe>.png im Ordner skins/obsidian bzw. skins/crying_obsidian/vanilla_obsidian).

GLINT
- Kategorie "Glint" ersetzt den Verzauberungs-Glanz (Items: enchanted_glint_item.png, Rüstung:
  enchanted_glint_armor.png). Pro Farbe gibt es <farbe>.png (Item) und <farbe>_armor.png (Rüstung).
- In skins.json kann ein Ziel eine "mcmeta" haben (wird als .mcmeta neben die Textur geschrieben).

NEUE KATEGORIE
In skins.json einen Block mit id, name, "targets" (Pfad der Vanilla-Textur, die ersetzt wird,
z. B. assets/minecraft/textures/item/mace.png) und "skins" ergänzen.

HINWEISE
- Die mitgelieferten Texturen sind einfache Platzhalter - ersetze sie durch deine.
- Die Mod erstellt beim Auswählen den Ordner resourcepacks/ZwettosTextures und aktiviert ihn.
- Crystal: ersetzt die Item-Textur UND die Textur des Crystals in der Welt. Die Welt-Textur liegt
  als <name>_entity.png neben der Item-Textur (siehe "suffix" in skins.json).
- Nicht getestet: Falls das Paket als "inkompatibel" angezeigt wird, pack_format in SkinManager.java anpassen.
