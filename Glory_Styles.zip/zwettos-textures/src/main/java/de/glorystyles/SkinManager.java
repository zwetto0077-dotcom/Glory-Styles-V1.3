package de.glorystyles;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

/**
 * Baut aus den gewählten Texturen (mit Sättigung/Helligkeit) ein Ordner-Ressourcenpaket
 * (resourcepacks/ZwettosTextures), aktiviert es und lädt die Ressourcen neu.
 */
public class SkinManager {
    private static final String PACK_NAME = "ZwettosTextures";
    private static final String PACK_ID = "file/" + PACK_NAME;

    private static Path packDir() {
        return FabricLoader.getInstance().getGameDir().resolve("resourcepacks").resolve(PACK_NAME);
    }

    public static void writePack() throws Exception {
        Path dir = packDir();
        if (Files.exists(dir)) {
            try (Stream<Path> s = Files.walk(dir)) {
                s.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
            }
        }
        Files.createDirectories(dir);
        Files.writeString(dir.resolve("pack.mcmeta"),
                "{\"pack\":{\"description\":\"Glory Styles\",\"pack_format\":75,\"min_format\":[75,0],\"max_format\":101}}");

        if (GeneralSettings.crystal3d) writeCrystal3d(dir);

        for (SkinIndex.Category cat : SkinIndex.CATEGORIES) {
            String skin = SkinConfig.get(cat.id());
            if (skin == null) continue;
            double sat = SkinConfig.getSat(cat.id());
            double bri = SkinConfig.getBri(cat.id());
            for (SkinIndex.Target target : cat.targets()) {
                String res = "/assets/glorystyles/textures/skins/" + cat.id() + "/" + skin + target.suffix() + ".png";
                try (InputStream in = SkinManager.class.getResourceAsStream(res)) {
                    if (in == null) continue;
                    byte[] data = in.readAllBytes();
                    if (!ImageAdjust.isNeutral(sat, bri)) {
                        try {
                            data = ImageAdjust.adjustedPng(new ByteArrayInputStream(data), sat, bri);
                        } catch (Throwable t) {
                            t.printStackTrace(); // Original behalten
                        }
                    }
                    Path out = dir.resolve(target.path());
                    Files.createDirectories(out.getParent());
                    Files.write(out, data);
                    if (target.mcmeta() != null) {
                        Files.writeString(Path.of(out.toString() + ".mcmeta"), target.mcmeta());
                    }
                }
            }
        }
    }

    /**
     * 3D Crystals: das End-Kristall-Item bekommt ein Würfel-Modell aus der Entity-Textur des Kristalls
     * (Glas, innerer Würfel, Kern, Sockel). Die Entity-Textur wird dafür zusätzlich in die Atlanten aufgenommen.
     */
    private static void writeCrystal3d(Path dir) throws Exception {
        Path mc = dir.resolve("assets/minecraft");
        Files.createDirectories(mc.resolve("items"));
        Files.createDirectories(mc.resolve("models/item"));
        Files.createDirectories(mc.resolve("atlases"));
        Files.writeString(mc.resolve("items/end_crystal.json"),
                "{\"model\":{\"type\":\"minecraft:model\",\"model\":\"minecraft:item/end_crystal_3d\"}}");
        String atlas = "{\"sources\":[{\"type\":\"minecraft:single\",\"resource\":\"minecraft:entity/end_crystal/end_crystal\"}]}";
        Files.writeString(mc.resolve("atlases/blocks.json"), atlas);
        Files.writeString(mc.resolve("atlases/items.json"), atlas);
        try (InputStream in = SkinManager.class.getResourceAsStream("/assets/glorystyles/crystal_3d_item.json")) {
            if (in != null) Files.write(mc.resolve("models/item/end_crystal_3d.json"), in.readAllBytes());
        }
    }

    /** @param forceReload true = immer neu laden (nach Auswahl im Menü) */
    public static void apply(boolean forceReload) {
        try {
            boolean any = !SkinConfig.all().isEmpty() || GeneralSettings.crystal3d;
            if (!any && !forceReload) return;
            writePack();

            MinecraftClient mc = MinecraftClient.getInstance();
            ResourcePackManager pm = mc.getResourcePackManager();
            pm.scanPacks();
            if (pm.getProfile(PACK_ID) == null) return;

            List<String> enabled = new ArrayList<>(pm.getEnabledIds());
            if (!enabled.contains(PACK_ID)) {
                enabled.add(PACK_ID); // ganz oben = höchste Priorität
                pm.setEnabledProfiles(enabled);
                mc.options.refreshResourcePacks(pm); // lädt neu, wenn sich die Liste ändert
            } else if (forceReload) {
                mc.reloadResources();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
