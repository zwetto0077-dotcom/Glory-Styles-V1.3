package de.glorystyles;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class GloryStylesClient implements ClientModInitializer {
    public static final String MOD_ID = "glorystyles";
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        SkinIndex.load();
        SkinConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
        openKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.glorystyles.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new GloryStylesScreen());
                }
            }
        });

        // Beim Start: gewählte Texturen als Ressourcenpaket bereitstellen und aktivieren
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> SkinManager.apply(false));
    }
}
