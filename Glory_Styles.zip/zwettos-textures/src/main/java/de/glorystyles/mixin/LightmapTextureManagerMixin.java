package de.glorystyles.mixin;

import de.glorystyles.GeneralSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Game Brightness über 100 %: hebt den Helligkeitswert (Gamma) der Lightmap an. Dadurch wird es heller
 * als Vanilla, aber nicht wie Fullbright.
 */
@Mixin(LightmapTextureManager.class)
public class LightmapTextureManagerMixin {
    @Redirect(method = "update",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;"),
            require = 0)
    private Object glorystyles$gamma(SimpleOption<?> option) {
        Object v = option.getValue();
        int b = GeneralSettings.gameBrightness;
        if (b > 100 && v instanceof Double d && option == MinecraftClient.getInstance().options.getGamma()) {
            return d + (b - 100) / 50.0 * 0.6;
        }
        return v;
    }
}
