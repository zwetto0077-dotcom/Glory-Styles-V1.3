package de.glorystyles.mixin;

import de.glorystyles.GeneralSettings;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Crystal Glow: End-Kristalle werden je nach Regler heller (bis voll leuchtend). */
@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {
    @Inject(method = "getLight", at = @At("RETURN"), cancellable = true, require = 0)
    private void glorystyles$crystalGlow(Entity entity, float tickProgress, CallbackInfoReturnable<Integer> cir) {
        int glow = GeneralSettings.crystalGlow;
        if (glow <= 0 || !(entity instanceof EndCrystalEntity)) return;
        float g = glow / 100.0f;
        int light = cir.getReturnValue();
        int block = LightmapTextureManager.getBlockLightCoordinates(light);
        int sky = LightmapTextureManager.getSkyLightCoordinates(light);
        block = Math.round(block + (15 - block) * g);
        sky = Math.round(sky + (15 - sky) * g);
        cir.setReturnValue(LightmapTextureManager.pack(block, sky));
    }
}
