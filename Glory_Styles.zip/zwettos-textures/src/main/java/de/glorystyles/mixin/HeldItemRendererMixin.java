package de.glorystyles.mixin;

import de.glorystyles.GeneralSettings;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ego-Perspektive: Item size (skaliert das Item in der Hand) und Low Shield (Schild hängt tiefer).
 */
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Unique
    private boolean glorystyles$pushed = false;

    private static final String RENDER_ITEM =
            "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;"
                    + "Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V";

    @Inject(method = RENDER_ITEM, at = @At("HEAD"), require = 0)
    private void glorystyles$sizeStart(LivingEntity entity, ItemStack stack, ItemDisplayContext context,
                                    MatrixStack matrices, OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        int size = GeneralSettings.itemSize;
        glorystyles$pushed = false;

        boolean shield = stack.isOf(Items.SHIELD)
                && (context == ItemDisplayContext.FIRST_PERSON_LEFT_HAND
                || context == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND);
        float low = shield ? (100 - GeneralSettings.lowShield) / 100.0f : 0.0f;
        if (size == 100 && low <= 0.0f) return;

        matrices.push();
        if (low > 0.0f) matrices.translate(0.0, -low, 0.0); // Low Shield: Schild nach unten schieben
        if (size != 100) {
            float f = size / 100.0f;
            matrices.scale(f, f, f);
        }
        glorystyles$pushed = true;
    }

    @Inject(method = RENDER_ITEM, at = @At("RETURN"), require = 0)
    private void glorystyles$sizeEnd(LivingEntity entity, ItemStack stack, ItemDisplayContext context,
                                  MatrixStack matrices, OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        if (glorystyles$pushed) {
            matrices.pop();
            glorystyles$pushed = false;
        }
    }
}
