package de.glorystyles.mixin;

import de.glorystyles.GeneralSettings;
import net.minecraft.client.particle.BillboardParticle;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Partikel: 100 % = Vanilla, darunter werden alle Partikel immer durchsichtiger, 0 % = unsichtbar. */
@Mixin(BillboardParticle.class)
public abstract class BillboardParticleMixin extends Particle {
    @Unique
    private float glorystyles$origAlpha;
    @Unique
    private boolean glorystyles$changed = false;

    protected BillboardParticleMixin(ClientWorld world, double x, double y, double z) {
        super(world, x, y, z);
    }

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void glorystyles$fadeStart(CallbackInfo ci) {
        int p = GeneralSettings.particles;
        glorystyles$changed = false;
        if (p >= 100) return;
        glorystyles$origAlpha = this.alpha;
        this.alpha = glorystyles$origAlpha * Math.max(0, p) / 100.0f;
        glorystyles$changed = true;
    }

    @Inject(method = "render", at = @At("RETURN"), require = 0)
    private void glorystyles$fadeEnd(CallbackInfo ci) {
        if (glorystyles$changed) {
            this.alpha = glorystyles$origAlpha;
            glorystyles$changed = false;
        }
    }
}
