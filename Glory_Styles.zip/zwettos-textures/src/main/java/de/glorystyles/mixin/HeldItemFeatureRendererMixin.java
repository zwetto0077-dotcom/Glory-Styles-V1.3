package de.glorystyles.mixin;

import de.glorystyles.GeneralSettings;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.state.ArmedEntityRenderState;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Item size (3. Person): skaliert das Item direkt vor dem Zeichnen an der Hand. */
@Mixin(HeldItemFeatureRenderer.class)
public class HeldItemFeatureRendererMixin {
    @Inject(method = "renderItem",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/ItemRenderState;render"),
            require = 0)
    private void glorystyles$size(ArmedEntityRenderState state, ItemRenderState itemState, ItemStack stack, Arm arm,
                               MatrixStack matrices, OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        int size = GeneralSettings.itemSize;
        if (size == 100) return;
        float f = size / 100.0f;
        matrices.scale(f, f, f); // wirkt bis zum pop() am Ende der Methode
    }
}
