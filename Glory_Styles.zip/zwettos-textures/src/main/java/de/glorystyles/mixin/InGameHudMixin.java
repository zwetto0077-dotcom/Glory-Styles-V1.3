package de.glorystyles.mixin;

import de.glorystyles.GeneralSettings;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Game Brightness unter 100 %: dunkelt die gezeichnete Welt (Blöcke, Himmel, Mobs ...) ab.
 * Läuft direkt vor dem HUD, daher bleiben HUD, Menüs und Inventar-Items unverändert.
 */
@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void glorystyles$dim(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        int b = GeneralSettings.gameBrightness;
        if (b >= 100) return;
        int alpha = Math.round((1.0f - Math.max(1, b) / 100.0f) * 255.0f);
        context.fill(0, 0, context.getScaledWindowWidth(), context.getScaledWindowHeight(), alpha << 24);
    }
}
