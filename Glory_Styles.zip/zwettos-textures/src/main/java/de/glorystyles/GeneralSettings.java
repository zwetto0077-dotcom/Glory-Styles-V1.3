package de.glorystyles;

/** Allgemeine Einstellungen (Bereich "Allgemeine Texturen"); die Mixins lesen diese Werte. */
public class GeneralSettings {
    /** 0 = aus, 100 = End-Kristalle leuchten komplett. */
    public static volatile int crystalGlow = 0;
    /** 1..150, 100 = Vanilla: Größe der Items in der Hand. */
    public static volatile int itemSize = 100;
    /** 0..100, 100 = Vanilla: Sichtbarkeit (Deckkraft) der Partikel. */
    public static volatile int particles = 100;
    /** 1..150, 100 = Vanilla: Helligkeit der Welt (Blöcke, Himmel, Mobs), nicht von GUI und Items. */
    public static volatile int gameBrightness = 100;
    /** true = End-Kristall-Item wird als 3D-Modell wie der platzierte Kristall angezeigt. */
    public static volatile boolean crystal3d = false;
    /** 1..100, 100 = Vanilla: je kleiner, desto tiefer hängt das Schild (Ego-Perspektive). */
    public static volatile int lowShield = 100;
}
