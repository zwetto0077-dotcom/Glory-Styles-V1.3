package de.glorystyles;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.InputSupplier;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Lädt Texturen direkt aus dem Vanilla-Ressourcenpaket von Minecraft (unabhängig von aktiven
 * Texturpaketen). Es wird nichts mit der Mod ausgeliefert - die Originale kommen zur Laufzeit aus dem Spiel.
 */
public class VanillaTextures {
    private static final Map<String, Tex> CACHE = new HashMap<>();

    /** @param path z. B. "textures/item/ender_pearl.png"; null, wenn nicht ladbar */
    public static Tex get(String path) {
        if (path == null) return null;
        if (CACHE.containsKey(path)) return CACHE.get(path);

        Tex result = null;
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            InputSupplier<InputStream> supplier =
                    mc.getDefaultResourcePack().open(ResourceType.CLIENT_RESOURCES, Identifier.ofVanilla(path));
            if (supplier != null) {
                try (InputStream in = supplier.get()) {
                    NativeImage image = NativeImage.read(in);
                    int w = image.getWidth(), h = image.getHeight();
                    Identifier id = Identifier.of(GloryStylesClient.MOD_ID, "vanilla/" + path.replace(".png", ""));
                    mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(() -> "glorystyles vanilla", image));
                    result = new Tex(id, w, h);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        CACHE.put(path, result);
        return result;
    }
}
