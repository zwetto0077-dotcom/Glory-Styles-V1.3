package de.glorystyles;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/** Ändert Sättigung und Helligkeit eines PNG (Faktor 1.0 = unverändert). */
public class ImageAdjust {
    public static boolean isNeutral(double sat, double bri) {
        return Math.abs(sat - 1.0) < 0.001 && Math.abs(bri - 1.0) < 0.001;
    }

    public static byte[] adjustedPng(InputStream in, double sat, double bri) throws IOException {
        BufferedImage img = ImageIO.read(in);
        if (img == null) throw new IOException("Kein gültiges Bild");
        BufferedImage out = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < img.getHeight(); y++) {
            for (int x = 0; x < img.getWidth(); x++) {
                int argb = img.getRGB(x, y);
                int a = (argb >>> 24) & 0xFF;
                if (a == 0) {
                    out.setRGB(x, y, argb);
                    continue;
                }
                double[] hsv = rgbToHsv((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF);
                hsv[1] = clamp(hsv[1] * sat);
                hsv[2] = clamp(hsv[2] * bri);
                int rgb = hsvToRgb(hsv[0], hsv[1], hsv[2]);
                out.setRGB(x, y, (a << 24) | rgb);
            }
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ImageIO.write(out, "png", bos);
        return bos.toByteArray();
    }

    private static double clamp(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }

    private static double[] rgbToHsv(int r, int g, int b) {
        double rf = r / 255.0, gf = g / 255.0, bf = b / 255.0;
        double max = Math.max(rf, Math.max(gf, bf)), min = Math.min(rf, Math.min(gf, bf));
        double d = max - min, h;
        if (d == 0) h = 0;
        else if (max == rf) h = ((gf - bf) / d) % 6;
        else if (max == gf) h = (bf - rf) / d + 2;
        else h = (rf - gf) / d + 4;
        h /= 6.0;
        if (h < 0) h += 1.0;
        return new double[]{h, max == 0 ? 0 : d / max, max};
    }

    private static int hsvToRgb(double h, double s, double v) {
        double c = v * s;
        double hp = (h * 6.0) % 6.0;
        double x = c * (1 - Math.abs(hp % 2 - 1));
        double r = 0, g = 0, b = 0;
        if (hp < 1) { r = c; g = x; }
        else if (hp < 2) { r = x; g = c; }
        else if (hp < 3) { g = c; b = x; }
        else if (hp < 4) { g = x; b = c; }
        else if (hp < 5) { r = x; b = c; }
        else { r = c; b = x; }
        double m = v - c;
        int ri = (int) Math.round((r + m) * 255);
        int gi = (int) Math.round((g + m) * 255);
        int bi = (int) Math.round((b + m) * 255);
        return (ri << 16) | (gi << 8) | bi;
    }
}
