package de.glorystyles;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Speichert pro Kategorie die gewählte Textur sowie Sättigung und Helligkeit (Faktor, 1.0 = normal)
 * in config/glorystyles.json.
 */
public class SkinConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Map<String, String> selected = new HashMap<>();
    private static Map<String, Double> sat = new HashMap<>();
    private static Map<String, Double> bri = new HashMap<>();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("glorystyles.json");
    }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            JsonObject root = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
            if (root.has("selected")) {
                selected = readStrings(root.getAsJsonObject("selected"));
                if (root.has("saturation")) sat = readDoubles(root.getAsJsonObject("saturation"));
                if (root.has("brightness")) bri = readDoubles(root.getAsJsonObject("brightness"));
                if (root.has("general")) {
                    JsonObject g = root.getAsJsonObject("general");
                    if (g.has("crystalGlow")) GeneralSettings.crystalGlow = clampInt(g.get("crystalGlow").getAsInt(), 0, 100);
                    if (g.has("itemSize")) GeneralSettings.itemSize = clampInt(g.get("itemSize").getAsInt(), 1, 150);
                    if (g.has("particles")) GeneralSettings.particles = clampInt(g.get("particles").getAsInt(), 0, 100);
                    if (g.has("gameBrightness")) GeneralSettings.gameBrightness = clampInt(g.get("gameBrightness").getAsInt(), 1, 150);
                    if (g.has("crystal3d")) GeneralSettings.crystal3d = g.get("crystal3d").getAsBoolean();
                    if (g.has("lowShield")) GeneralSettings.lowShield = clampInt(g.get("lowShield").getAsInt(), 1, 100);
                }
            } else {
                selected = readStrings(root); // altes Format
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static int clampInt(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static Map<String, String> readStrings(JsonObject o) {
        Map<String, String> m = new HashMap<>();
        for (Map.Entry<String, JsonElement> e : o.entrySet()) m.put(e.getKey(), e.getValue().getAsString());
        return m;
    }

    private static Map<String, Double> readDoubles(JsonObject o) {
        Map<String, Double> m = new HashMap<>();
        for (Map.Entry<String, JsonElement> e : o.entrySet()) m.put(e.getKey(), e.getValue().getAsDouble());
        return m;
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            root.add("selected", GSON.toJsonTree(selected));
            root.add("saturation", GSON.toJsonTree(sat));
            root.add("brightness", GSON.toJsonTree(bri));
            JsonObject g = new JsonObject();
            g.addProperty("crystalGlow", GeneralSettings.crystalGlow);
            g.addProperty("itemSize", GeneralSettings.itemSize);
            g.addProperty("particles", GeneralSettings.particles);
            g.addProperty("gameBrightness", GeneralSettings.gameBrightness);
            g.addProperty("crystal3d", GeneralSettings.crystal3d);
            g.addProperty("lowShield", GeneralSettings.lowShield);
            root.add("general", g);
            Files.writeString(file(), GSON.toJson(root));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** null = Standard-Textur */
    public static String get(String categoryId) {
        return selected.get(categoryId);
    }

    public static void set(String categoryId, String skinId) {
        if (skinId == null) selected.remove(categoryId);
        else selected.put(categoryId, skinId);
        save();
    }

    public static Map<String, String> all() {
        return selected;
    }

    public static double getSat(String categoryId) {
        return sat.getOrDefault(categoryId, 1.0);
    }

    public static double getBri(String categoryId) {
        return bri.getOrDefault(categoryId, 1.0);
    }

    /** Speichert nur im Speicher; save() schreibt die Datei. */
    public static void setSat(String categoryId, double factor) {
        if (Math.abs(factor - 1.0) < 0.001) sat.remove(categoryId);
        else sat.put(categoryId, factor);
    }

    public static void setBri(String categoryId, double factor) {
        if (Math.abs(factor - 1.0) < 0.001) bri.remove(categoryId);
        else bri.put(categoryId, factor);
    }
}
