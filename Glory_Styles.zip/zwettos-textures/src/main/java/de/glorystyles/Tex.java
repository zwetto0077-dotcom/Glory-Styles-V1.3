package de.glorystyles;

import net.minecraft.util.Identifier;

/** Eine Textur mit ihrer Pixelgröße (wird für die UV-Berechnung der 3D-Vorschau gebraucht). */
public record Tex(Identifier id, int w, int h) {}
