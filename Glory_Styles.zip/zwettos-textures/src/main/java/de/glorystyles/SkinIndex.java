package de.glorystyles;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Liest assets/glorystyles/skins.json (Kategorien, optional Unterkategorien, Texturen). */
public class SkinIndex {
    /** path = Zielpfad im Ressourcenpaket, suffix = Endung der Quelltextur (z. B. "_entity"). */
    /** mcmeta = optionaler JSON-Text für die .mcmeta-Datei neben der Textur (z. B. {"texture":{"blur":true}}). */
    public record Target(String path, String suffix, String mcmeta) {}

    /** Unterkategorie (z. B. ein Crystal-Design) mit ihren Farben. id "" = Kategorie ohne Unterkategorien. */
    public record Group(String id, String name, List<String> skins) {}

    /** icon = Vanilla-Textur (z. B. textures/item/ender_pearl.png) für Sidebar und "Standard". preview: "item" = große Textur rechts, "player" = Spieler mit verzauberter Rüstung (für Glints). */
    public record Category(String id, String name, List<Target> targets, List<Group> groups, boolean grouped, String preview, String icon) {}

    public static final List<Category> CATEGORIES = new ArrayList<>();

    public static void load() {
        CATEGORIES.clear();
        try (InputStream in = SkinIndex.class.getResourceAsStream("/assets/glorystyles/skins.json")) {
            if (in == null) return;
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            for (var el : root.getAsJsonArray("categories")) {
                JsonObject o = el.getAsJsonObject();

                List<Target> targets = new ArrayList<>();
                o.getAsJsonArray("targets").forEach(t -> {
                    if (t.isJsonPrimitive()) {
                        targets.add(new Target(t.getAsString(), "", null));
                    } else {
                        JsonObject to = t.getAsJsonObject();
                        targets.add(new Target(to.get("path").getAsString(),
                                to.has("suffix") ? to.get("suffix").getAsString() : "",
                                to.has("mcmeta") ? to.get("mcmeta").toString() : null));
                    }
                });

                List<Group> groups = new ArrayList<>();
                boolean grouped = o.has("groups");
                if (grouped) {
                    for (var ge : o.getAsJsonArray("groups")) {
                        JsonObject go = ge.getAsJsonObject();
                        groups.add(new Group(go.get("id").getAsString(), go.get("name").getAsString(), readSkins(go)));
                    }
                } else {
                    groups.add(new Group("", "", readSkins(o)));
                }
                CATEGORIES.add(new Category(o.get("id").getAsString(), o.get("name").getAsString(), targets, groups, grouped,
                        o.has("preview") ? o.get("preview").getAsString() : "item",
                        o.has("icon") ? o.get("icon").getAsString() : null));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static List<String> readSkins(JsonObject o) {
        List<String> skins = new ArrayList<>();
        o.getAsJsonArray("skins").forEach(s -> skins.add(s.getAsString()));
        return skins;
    }
}
