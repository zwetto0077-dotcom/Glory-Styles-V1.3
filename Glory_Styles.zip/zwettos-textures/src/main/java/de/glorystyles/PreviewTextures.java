package de.glorystyles;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Erzeugt die Vorschau-Texturen live (mit Sättigung/Helligkeit aus den Reglern). */
public class PreviewTextures {
    private static final Map<String, String> KEYS = new HashMap<>();
    private static final Map<String, Tex> TEX = new HashMap<>();

    /** @param slot Name des Vorschau-Platzes (z. B. "item" oder "ent"); jeder Platz hat genau eine Textur */
    public static Tex get(String slot, String resourcePath, double sat, double bri) {
        String key = resourcePath + "|" + Math.round(sat * 100) + "|" + Math.round(bri * 100);
        if (key.equals(KEYS.get(slot))) return TEX.get(slot);

        Tex result = null;
        try (InputStream in = PreviewTextures.class.getResourceAsStream(resourcePath)) {
            if (in != null) {
                byte[] raw = in.readAllBytes();
                byte[] png = raw;
                if (!ImageAdjust.isNeutral(sat, bri)) {
                    try {
                        png = ImageAdjust.adjustedPng(new ByteArrayInputStream(raw), sat, bri);
                    } catch (Throwable t) {
                        png = raw;
                    }
                }
                NativeImage image = NativeImage.read(new ByteArrayInputStream(png));
                int w = image.getWidth(), h = image.getHeight();
                Identifier id = Identifier.of(GloryStylesClient.MOD_ID, "preview/" + slot);
                MinecraftClient.getInstance().getTextureManager()
                        .registerTexture(id, new NativeImageBackedTexture(() -> "glorystyles preview", image));
                result = new Tex(id, w, h);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        KEYS.put(slot, key);
        TEX.put(slot, result);
        return result;
    }
}
