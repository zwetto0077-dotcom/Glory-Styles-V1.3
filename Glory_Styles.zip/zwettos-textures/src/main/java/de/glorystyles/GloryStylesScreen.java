package de.glorystyles;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.DoubleConsumer;

/**
 * Sauberes, dunkles Menü: Formen werden in echten Bildschirm-Pixeln mit weichen Kanten gezeichnet
 * (glatte Rundungen, unabhängig von der GUI-Skalierung). Rechts eine Vorschau mit drehendem Item,
 * 3D-Crystal bzw. Block sowie Reglern für Sättigung und Helligkeit.
 */
public class GloryStylesScreen extends Screen {
    // Farben (ARGB)
    private static final int C_PANEL = 0xF2121620;
    private static final int C_SIDEBAR = 0xF20D1018;
    private static final int C_CARD = 0xFF222838;
    private static final int C_CARD_HI = 0xFF2D3550;
    private static final int C_CHIP = 0xFF1B2130;
    private static final int C_TRACK = 0xFF343C52;
    private static final int C_ACCENT = 0xFF2563EB;
    private static final int C_ACCENT_HI = 0xFF4A86FF;
    private static final int C_TEXT = 0xFFE6E9F0;
    private static final int C_MUTED = 0xFF8A92A6;
    private static final int C_DOT = 0xFF3A4256;
    private static final int C_WHITE = 0xFFFFFFFF;
    private static final int C_ORANGE = 0xFFFF9F1C;
    private static final int C_ORANGE_HI = 0xFFFFB84D;

    private static final String DISCORD_URL = "https://discord.gg/Yzpun6VXqQ";
    private static final String[] MAIN_LABELS = {"Glory Clan", "Allgemeine Texturen", "Textures"};
    private static final String[] MAIN_ICONS = {"textures/item/golden_helmet.png", "textures/item/book.png",
            "textures/item/painting.png"};

    private static final int GAP = 6;
    private static final int CARD_H = 72;
    private static final int LABEL_H = 18;
    private static final int ICON = 32;

    private record Card(int x, int y, int w, int h, String label, String value, boolean selected, boolean marked, Identifier tex) {}
    private record Item(int x, int y, int w, int h, String label, boolean selected, boolean pending, Identifier icon) {}
    private record Chip(int x, int y, int w, int h, String label, boolean selected) {}

    /** Unsichtbarer Regler (Klick/Ziehen übernimmt Minecraft), gezeichnet wird selbst. */
    private static class Slider extends SliderWidget {
        private final DoubleConsumer onChange;

        Slider(int x, int y, int w, int h, double value, DoubleConsumer onChange) {
            super(x, y, w, h, Text.empty(), Math.max(0.0, Math.min(1.0, value)));
            this.onChange = onChange;
        }

        @Override
        protected void updateMessage() {}

        @Override
        protected void applyValue() {
            onChange.accept(this.value);
        }

        double t() {
            return this.value;
        }
    }

    /** Ein Bildschirm-Dreieck der 3D-Vorschau (Würfelfläche). */
    private static class FaceDraw {
        Tex tex;
        float u, v;
        int rw, rh;
        double ox, oy, ux, uy, vx, vy, depth;
    }

    // Skalierung: gs = GUI-Skalierung von Minecraft, ui = echte Pixel pro Layout-Einheit
    private double gs = 1;
    private int ui = 2;
    private int sidebarW = 124;

    private int section = 2; // 0 = Glory Clan, 1 = Allgemeine Texturen, 2 = Textures
    private int catHeadY = -1;
    private int[] pageCard = new int[4];
    private int[] clanOpenRect = null;
    private int[] clanCopyRect = null;
    private long copiedUntil = 0;
    private static final int GEN_BLOCK = 28;
    private static final int TOGGLE_BLOCK = 22;
    private int[] toggleRect = null;
    private static final String[] GEN_NAMES = {"Crystal Glow", "Item size", "Partikel", "Game Brightness",
            "Low Shield"};
    private static final String[] GEN_HINTS = {
            "End-Kristalle leuchten",
            "Größe in der Hand",
            "Durchsichtigkeit",
            "Helligkeit der Welt",
            "Schild tiefer halten"};
    private Slider[] genSliders = null;
    private int catIndex = 0;
    private int groupIndex = 0;
    private int page = 0;
    private int maxPage = 0;

    // Layout in Einheiten (wird in rebuild() gefüllt)
    private int px, py, pw, ph;
    private int contentX, contentRight, gridTop;
    private int previewX, previewY, previewW, previewH;
    private int navY;
    private int previewBottom;
    private final List<Card> cards = new ArrayList<>();
    private final List<Item> items = new ArrayList<>();
    private final List<Chip> chips = new ArrayList<>();
    private int[] closeRect = new int[4];
    private int[] prevRect = null;
    private int[] nextRect = null;
    private int[] resetRect = null;
    private Slider satSlider = null;
    private Slider briSlider = null;
    private int sliderTop;

    // Markierte (noch nicht angewendete) Änderungen: Kategorie -> Textur (null = Standard)
    private final Map<String, String> pending = new HashMap<>();
    private final Map<String, Double> pendSat = new HashMap<>();
    private final Map<String, Double> pendBri = new HashMap<>();
    private int[] applyRect = new int[4];
    private final long startNanos = System.nanoTime();

    private LivingEntity previewPlayer;
    private ClientWorld previewWorld;

    public GloryStylesScreen() {
        super(Text.literal("Glory Styles"));
    }

    @Override
    protected void init() {
        rebuild();
    }

    @Override
    public void removed() {
        SkinConfig.save(); // speichert auch die allgemeinen Einstellungen
        super.removed();
    }

    // ------------------------------------------------------------------ Aufbau

    private boolean hasPending(String catId) {
        return pending.containsKey(catId) || pendSat.containsKey(catId) || pendBri.containsKey(catId);
    }

    private boolean hasPending() {
        return !pending.isEmpty() || !pendSat.isEmpty() || !pendBri.isEmpty();
    }

    private int pendingCount() {
        Set<String> cats = new HashSet<>(pending.keySet());
        cats.addAll(pendSat.keySet());
        cats.addAll(pendBri.keySet());
        return cats.size();
    }

    /** Aktuell gültige Auswahl/Regler einer Kategorie inklusive markierter Änderungen. */
    private String effSelected(String catId) {
        return pending.containsKey(catId) ? pending.get(catId) : SkinConfig.get(catId);
    }

    private double effSat(String catId) {
        return pendSat.containsKey(catId) ? pendSat.get(catId) : SkinConfig.getSat(catId);
    }

    private double effBri(String catId) {
        return pendBri.containsKey(catId) ? pendBri.get(catId) : SkinConfig.getBri(catId);
    }

    /** Übernimmt alle markierten Texturen und Regler und lädt sie im Spiel. */
    private void applyPending() {
        if (!hasPending()) return;
        for (Map.Entry<String, String> e : pending.entrySet()) SkinConfig.set(e.getKey(), e.getValue());
        for (Map.Entry<String, Double> e : pendSat.entrySet()) SkinConfig.setSat(e.getKey(), e.getValue());
        for (Map.Entry<String, Double> e : pendBri.entrySet()) SkinConfig.setBri(e.getKey(), e.getValue());
        pending.clear();
        pendSat.clear();
        pendBri.clear();
        SkinConfig.save();
        SkinManager.apply(true);
        rebuild();
    }

    private int toGui(double units) {
        return (int) Math.round(units * ui / gs);
    }

    private void addHit(int x, int y, int w, int h, Runnable action) {
        this.addSelectableChild(ButtonWidget.builder(Text.empty(), b -> action.run())
                .dimensions(toGui(x), toGui(y), Math.max(1, toGui(w)), Math.max(1, toGui(h))).build());
    }

    private void rebuild() {
        this.clearChildren();
        cards.clear();
        items.clear();
        chips.clear();
        prevRect = null;
        nextRect = null;
        resetRect = null;
        satSlider = null;
        briSlider = null;
        clanOpenRect = null;
        clanCopyRect = null;
        genSliders = null;
        toggleRect = null;
        maxPage = 0;
        if (SkinIndex.CATEGORIES.isEmpty() || this.client == null) return;

        // Eigene Skalierung: ganzzahlig, damit Pixel-Texturen sauber bleiben
        var window = this.client.getWindow();
        gs = window.getScaleFactor();
        int physW = window.getFramebufferWidth();
        int physH = window.getFramebufferHeight();
        ui = Math.max(1, Math.min(physW / 540, physH / 300));
        int vw = physW / ui;
        int vh = physH / ui;

        px = 8;
        py = 8;
        pw = vw - 16;
        ph = vh - 16;
        int titleW = this.textRenderer.getWidth(Text.literal("Glory Styles").formatted(Formatting.BOLD));
        sidebarW = Math.max(124, titleW + 28);
        contentX = px + sidebarW + 14;
        contentRight = px + pw - 14;
        int inner = contentRight - contentX;

        closeRect = new int[]{px + pw - 30, py + 10, 20, 20};
        addHit(closeRect[0], closeRect[1], closeRect[2], closeRect[3], this::close);
        applyRect = new int[]{px + pw - 30 - 8 - 104, py + 9, 104, 22};
        addHit(applyRect[0], applyRect[1], applyRect[2], applyRect[3], this::applyPending); // wirkt nur, wenn etwas markiert ist

        // Sidebar: Hauptbereiche
        int sy = py + 40;
        for (int i = 0; i < MAIN_LABELS.length; i++) {
            final int sec = i;
            Tex ic = VanillaTextures.get(MAIN_ICONS[i]);
            items.add(new Item(px + 10, sy, sidebarW - 20, 24, MAIN_LABELS[i], section == i,
                    i == 2 && hasPending(), ic != null ? ic.id() : null));
            addHit(px + 10, sy, sidebarW - 20, 24, () -> {
                section = sec;
                page = 0;
                rebuild();
            });
            sy += 28;
        }

        // Unter "Textures": alle Kategorien (Höhe passt sich dem Platz an)
        catHeadY = -1;
        if (section == 2) {
            catHeadY = sy + 4;
            sy += 20;
            int count = SkinIndex.CATEGORIES.size();
            int avail = (py + ph - 46) - sy;
            int pitch = Math.max(15, Math.min(24, avail / Math.max(1, count)));
            for (int i = 0; i < count; i++) {
                final int idx = i;
                SkinIndex.Category c = SkinIndex.CATEGORIES.get(i);
                int ix = px + 18, iy = sy + i * pitch, iw = sidebarW - 28, ih = pitch - 3;
                items.add(new Item(ix, iy, iw, ih, c.name(), i == catIndex, hasPending(c.id()), iconFor(c)));
                addHit(ix, iy, iw, ih, () -> {
                    catIndex = idx;
                    groupIndex = 0;
                    page = 0;
                    rebuild();
                });
            }
        }

        if (section != 2) {
            buildInfoPage(inner);
            return;
        }

        SkinIndex.Category cat = SkinIndex.CATEGORIES.get(catIndex);
        if (groupIndex >= cat.groups().size()) groupIndex = 0;
        SkinIndex.Group group = cat.groups().get(groupIndex);
        String current = SkinConfig.get(cat.id()); // aktuell angewendet

        // Vorschau rechts
        previewW = Math.max(150, Math.min(210, inner * 34 / 100));
        int gridW = inner - previewW - 10;
        previewX = contentX + gridW + 10;
        previewY = py + 40;
        previewH = py + ph - 14 - previewY;
        previewBottom = previewY + previewH - 10;

        // Regler + Zurücksetzen (nur wenn genug Platz)
        if (previewH >= 200) {
            int sx = previewX + 12, sw = previewW - 24;
            sliderTop = previewY + previewH - 76;
            satSlider = new Slider(toGui(sx), toGui(sliderTop + 10), Math.max(8, toGui(sw)), Math.max(6, toGui(12)),
                    effSat(cat.id()) / 2.0, t -> onAdjust(cat, true, t));
            briSlider = new Slider(toGui(sx), toGui(sliderTop + 10 + 24), Math.max(8, toGui(sw)), Math.max(6, toGui(12)),
                    effBri(cat.id()) / 2.0, t -> onAdjust(cat, false, t));
            this.addSelectableChild(satSlider);
            this.addSelectableChild(briSlider);
            resetRect = new int[]{previewX + 12, previewY + previewH - 24, previewW - 24, 16};
            addHit(resetRect[0], resetRect[1], resetRect[2], resetRect[3], () -> {
                markAdjust(cat.id(), true, 1.0);
                markAdjust(cat.id(), false, 1.0);
                rebuild();
            });
            previewBottom = sliderTop - 6;
        }

        // Chips (Unterkategorien)
        int top = py + 40;
        if (cat.grouped()) {
            int cx = contentX;
            for (int i = 0; i < cat.groups().size(); i++) {
                final int gi = i;
                SkinIndex.Group g = cat.groups().get(i);
                int w = this.textRenderer.getWidth(g.name()) + 18;
                if (cx + w > contentX + gridW && cx > contentX) break;
                chips.add(new Chip(cx, top, w, 18, g.name(), i == groupIndex));
                addHit(cx, top, w, 18, () -> {
                    groupIndex = gi;
                    page = 0;
                    rebuild();
                });
                cx += w + 5;
            }
            top += 18 + 10;
        }
        gridTop = top;

        // Karten: Eintrag 0 = Standard, danach alle Farben
        List<String> entries = new ArrayList<>();
        entries.add(null);
        entries.addAll(group.skins());

        int cols = gridW >= 330 ? 4 : 3;
        int cardW = (gridW - (cols - 1) * GAP) / cols;
        int avail = (py + ph - 14) - gridTop;
        int rows = Math.max(1, (avail + GAP) / (CARD_H + GAP));
        boolean needNav = entries.size() > cols * rows;
        if (needNav) rows = Math.max(1, (avail - 24 + GAP) / (CARD_H + GAP));
        int perPage = cols * rows;
        maxPage = Math.max(0, (entries.size() - 1) / perPage);
        if (page > maxPage) page = maxPage;

        for (int n = 0; n < perPage; n++) {
            int e = page * perPage + n;
            if (e >= entries.size()) break;
            String skin = entries.get(e);
            String value = skin == null ? null : (group.id().isEmpty() ? skin : group.id() + "/" + skin);
            int x = contentX + (n % cols) * (cardW + GAP);
            int y = gridTop + (n / cols) * (CARD_H + GAP);
            boolean selected = (value == null && current == null) || (value != null && value.equals(current));
            boolean marked = pending.containsKey(cat.id()) && Objects.equals(pending.get(cat.id()), value);
            cards.add(new Card(x, y, cardW, CARD_H, skin == null ? "Standard" : skin, value, selected, marked,
                    value == null ? iconFor(cat) : skinTexture(cat, value)));
            addHit(x, y, cardW, CARD_H, () -> {
                // Klick markiert die Textur (orange Punkt); nochmal klicken hebt die Markierung auf
                if (marked || Objects.equals(value, current)) pending.remove(cat.id());
                else pending.put(cat.id(), value);
                rebuild();
            });
        }

        // Seiten-Navigation
        navY = py + ph - 14 - 18;
        if (maxPage > 0) {
            prevRect = new int[]{contentX, navY, 18, 18};
            nextRect = new int[]{contentX + 24, navY, 18, 18};
            addHit(prevRect[0], prevRect[1], 18, 18, () -> {
                page = Math.max(0, page - 1);
                rebuild();
            });
            addHit(nextRect[0], nextRect[1], 18, 18, () -> {
                page = Math.min(maxPage, page + 1);
                rebuild();
            });
        }
    }

    /** Seiten "Glory Clan" und "Allgemeine Texturen". */
    private void buildInfoPage(int inner) {
        int cw = Math.min(inner, 380);
        pageCard = new int[]{contentX, py + 40, cw, section == 0 ? 160 : 16 + GEN_NAMES.length * GEN_BLOCK + TOGGLE_BLOCK + 8};
        if (section == 0) {
            int by = pageCard[1] + pageCard[3] - 34;
            clanOpenRect = new int[]{contentX + 16, by, 120, 22};
            clanCopyRect = new int[]{contentX + 16 + 120 + 8, by, 110, 22};
            addHit(clanOpenRect[0], clanOpenRect[1], clanOpenRect[2], clanOpenRect[3], this::openDiscord);
            addHit(clanCopyRect[0], clanCopyRect[1], clanCopyRect[2], clanCopyRect[3], this::copyDiscord);
        } else {
            // Regler für Crystal Glow, Item size und Partikel
            int sx = contentX + 16, sw = cw - 32;
            double[] start = {GeneralSettings.crystalGlow / 100.0, (GeneralSettings.itemSize - 1) / 149.0,
                    GeneralSettings.particles / 100.0,
                    (GeneralSettings.gameBrightness - 1) / 149.0,
                    (GeneralSettings.lowShield - 1) / 99.0};
            genSliders = new Slider[GEN_NAMES.length];
            for (int i = 0; i < GEN_NAMES.length; i++) {
                final int idx = i;
                int by = pageCard[1] + 16 + i * GEN_BLOCK;
                genSliders[i] = new Slider(toGui(sx), toGui(by + 10), Math.max(8, toGui(sw)), Math.max(6, toGui(12)),
                        start[i], t -> onGeneral(idx, t));
                this.addSelectableChild(genSliders[i]);
            }
            // An/Aus-Schalter: 3D Crystals
            int ty = pageCard[1] + 16 + GEN_NAMES.length * GEN_BLOCK;
            toggleRect = new int[]{sx + sw - 28, ty - 3, 28, 14};
            addHit(sx, ty - 3, sw, 16, this::toggleCrystal3d);
        }
    }

    private void toggleCrystal3d() {
        GeneralSettings.crystal3d = !GeneralSettings.crystal3d;
        SkinConfig.save();
        SkinManager.apply(true); // Item-Modell kommt über das Ressourcenpaket, daher kurzes Neuladen
        rebuild();
    }

    private void onGeneral(int idx, double t) {
        switch (idx) {
            case 1, 3 -> {
                int v = (int) Math.round(1 + t * 149);
                if (Math.abs(v - 100) <= 2) v = 100;
                if (idx == 1) GeneralSettings.itemSize = v;
                else GeneralSettings.gameBrightness = v;
            }
            case 4 -> {
                int v = (int) Math.round(1 + t * 99);
                if (v >= 98) v = 100;
                GeneralSettings.lowShield = v;
            }
            default -> {
                int v = (int) Math.round(t * 100);
                if (v <= 2) v = 0;
                if (v >= 98) v = 100;
                if (idx == 0) GeneralSettings.crystalGlow = v;
                else GeneralSettings.particles = v;
            }
        }
    }

    private int genValue(int idx) {
        return switch (idx) {
            case 0 -> GeneralSettings.crystalGlow;
            case 1 -> GeneralSettings.itemSize;
            case 2 -> GeneralSettings.particles;
            case 3 -> GeneralSettings.gameBrightness;
            default -> GeneralSettings.lowShield;
        };
    }

    private void openDiscord() {
        try {
            net.minecraft.util.Util.getOperatingSystem().open(java.net.URI.create(DISCORD_URL));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void copyDiscord() {
        if (this.client == null) return;
        this.client.keyboard.setClipboard(DISCORD_URL);
        copiedUntil = System.currentTimeMillis() + 2000;
    }

    private void onAdjust(SkinIndex.Category cat, boolean saturation, double t) {
        double f = t * 2.0;
        if (Math.abs(f - 1.0) < 0.04) f = 1.0;
        markAdjust(cat.id(), saturation, f);
    }

    /** Merkt einen Reglerwert vor; ist er gleich dem angewendeten Wert, entfällt die Markierung. */
    private void markAdjust(String catId, boolean saturation, double f) {
        Map<String, Double> map = saturation ? pendSat : pendBri;
        double applied = saturation ? SkinConfig.getSat(catId) : SkinConfig.getBri(catId);
        if (Math.abs(f - applied) < 0.001) map.remove(catId);
        else map.put(catId, f);
    }

    private static Identifier skinTexture(SkinIndex.Category cat, String value) {
        return Identifier.of(GloryStylesClient.MOD_ID, "textures/skins/" + cat.id() + "/" + value + ".png");
    }

    /** Icon für die Sidebar und "Standard": das Vanilla-Item (Fallback: erste Farbe des ersten Designs). */
    private static Identifier iconFor(SkinIndex.Category c) {
        Tex v = VanillaTextures.get(c.icon());
        if (v != null) return v.id();
        SkinIndex.Group g = c.groups().get(0);
        if (g.skins().isEmpty()) return null;
        String value = g.id().isEmpty() ? g.skins().get(0) : g.id() + "/" + g.skins().get(0);
        return skinTexture(c, value);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (maxPage > 0 && verticalAmount != 0) {
            page = Math.max(0, Math.min(maxPage, page + (verticalAmount < 0 ? 1 : -1)));
            rebuild();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    // ----------------------------------------------------------- Zeichen-Helfer

    /** Abgerundetes Rechteck in Layout-Einheiten (nur in der Pixel-Ebene aufrufen). */
    private void rr(DrawContext c, double x, double y, double w, double h, double r, int color) {
        rrPx(c, (int) Math.round(x * ui), (int) Math.round(y * ui), (int) Math.round(w * ui),
                (int) Math.round(h * ui), (int) Math.round(r * ui), color);
    }

    private void fillU(DrawContext c, double x, double y, double w, double h, int color) {
        int x0 = (int) Math.round(x * ui), y0 = (int) Math.round(y * ui);
        c.fill(x0, y0, x0 + (int) Math.round(w * ui), y0 + (int) Math.round(h * ui), color);
    }

    /** Abgerundetes Rechteck in echten Bildschirm-Pixeln mit weichen Kanten. */
    private static void rrPx(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        int alpha = (color >>> 24) & 0xFF;
        int rgb = color & 0xFFFFFF;
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            double dx = r - Math.sqrt(r * (double) r - dy * dy);
            int k0 = (int) Math.floor(dx);
            double cov = 1.0 - (dx - k0);
            int xl = x + k0 + 1;
            int xr = x + w - k0 - 1;
            if (xr > xl) {
                c.fill(xl, y + i, xr, y + i + 1, color);
                c.fill(xl, y + h - 1 - i, xr, y + h - i, color);
            }
            int ea = (int) Math.round(alpha * cov);
            if (ea > 0) {
                int ec = (ea << 24) | rgb;
                c.fill(x + k0, y + i, x + k0 + 1, y + i + 1, ec);
                c.fill(x + w - k0 - 1, y + i, x + w - k0, y + i + 1, ec);
                c.fill(x + k0, y + h - 1 - i, x + k0 + 1, y + h - i, ec);
                c.fill(x + w - k0 - 1, y + h - 1 - i, x + w - k0, y + h - i, ec);
            }
        }
    }

    private static boolean inside(int x, int y, int w, int h, double mx, double my) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static boolean inside(int[] r, double mx, double my) {
        return r != null && inside(r[0], r[1], r[2], r[3], mx, my);
    }

    private static void drawTex(DrawContext ctx, Tex t, int x, int y, int w, int h) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, t.id(), x, y, 0f, 0f, w, h, t.w(), t.h(), t.w(), t.h());
    }

    // ----------------------------------------------------------------- Rendern

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta); // nur Hintergrund, Widgets sind unsichtbar
        if (SkinIndex.CATEGORIES.isEmpty() || this.client == null) return;
        SkinIndex.Category cat = SkinIndex.CATEGORIES.get(catIndex);

        double mu = mouseX * gs / ui;
        double mv = mouseY * gs / ui;
        double t = (System.nanoTime() - startNanos) / 1.0e9;

        // Hover-Karte bestimmen
        boolean hovering = false;
        String hoverValue = null;
        for (Card c : cards) {
            if (inside(c.x(), c.y(), c.w(), c.h(), mu, mv)) {
                hovering = true;
                hoverValue = c.value();
                break;
            }
        }

        Matrix3x2fStack m = ctx.getMatrices();

        // Ebene 1: Formen in echten Pixeln (glatte Rundungen)
        m.pushMatrix();
        m.scale((float) (1.0 / gs), (float) (1.0 / gs));
        drawShapes(ctx, mu, mv);
        m.popMatrix();

        // Ebene 2: Text, Icons, Vorschau in Layout-Einheiten
        m.pushMatrix();
        m.scale((float) (ui / gs), (float) (ui / gs));
        drawContent(ctx, cat, mu, mv, hovering, hoverValue, t);
        m.popMatrix();

        // Ebene 3: Spieler-Vorschau (Glint) in normalen GUI-Koordinaten
        if (section == 2 && "player".equals(cat.preview())) drawPlayer(ctx, mouseX, mouseY);
    }

    private void drawShapes(DrawContext ctx, double mu, double mv) {
        rr(ctx, px, py, pw, ph, 9, C_PANEL);
        rr(ctx, px, py, sidebarW, ph, 9, C_SIDEBAR);
        fillU(ctx, px + sidebarW - 9, py, 9, ph, C_SIDEBAR);
        int sepX = (int) Math.round((px + sidebarW) * ui);
        ctx.fill(sepX, (int) Math.round((py + 2) * ui), sepX + 1, (int) Math.round((py + ph - 2) * ui), 0x22FFFFFF);

        for (Item it : items) {
            boolean hover = inside(it.x(), it.y(), it.w(), it.h(), mu, mv);
            if (it.selected()) rr(ctx, it.x(), it.y(), it.w(), it.h(), 7, C_ACCENT);
            else if (hover) rr(ctx, it.x(), it.y(), it.w(), it.h(), 7, C_CARD);
        }
        ctx.fill((int) Math.round((px + 10) * ui), (int) Math.round((py + ph - 40) * ui),
                (int) Math.round((px + sidebarW - 10) * ui), (int) Math.round((py + ph - 40) * ui) + 1, 0x22FFFFFF);

        if (inside(closeRect, mu, mv)) rr(ctx, closeRect[0], closeRect[1], closeRect[2], closeRect[3], 10, C_CARD);
        for (Item it : items) {
            if (it.pending()) rr(ctx, it.x() + it.w() - 12, it.y() + it.h() / 2.0 - 3, 6, 6, 3, C_ORANGE);
        }
        if (hasPending()) {
            rr(ctx, applyRect[0], applyRect[1], applyRect[2], applyRect[3], 11,
                    inside(applyRect, mu, mv) ? C_ORANGE_HI : C_ORANGE);
        }

        for (Chip ch : chips) {
            boolean hover = inside(ch.x(), ch.y(), ch.w(), ch.h(), mu, mv);
            rr(ctx, ch.x(), ch.y(), ch.w(), ch.h(), ch.h() / 2.0, ch.selected() ? C_ACCENT : (hover ? C_CARD_HI : C_CHIP));
        }

        for (Card c : cards) {
            boolean hover = inside(c.x(), c.y(), c.w(), c.h(), mu, mv);
            if (c.marked()) rr(ctx, c.x() - 1, c.y() - 1, c.w() + 2, c.h() + 2, 9, C_ORANGE);
            else if (c.selected()) rr(ctx, c.x() - 1, c.y() - 1, c.w() + 2, c.h() + 2, 9, C_ACCENT_HI);
            rr(ctx, c.x(), c.y(), c.w(), c.h(), 8, hover ? C_CARD_HI : C_CARD);
            rr(ctx, c.x(), c.y() + c.h() - LABEL_H, c.w(), LABEL_H, 8, C_ACCENT);
            fillU(ctx, c.x(), c.y() + c.h() - LABEL_H, c.w(), 8, C_ACCENT);
            rr(ctx, c.x() + c.w() - 13, c.y() + 7, 6, 6, 3, c.marked() ? C_ORANGE : (c.selected() ? C_ACCENT_HI : C_DOT));
        }

        if (maxPage > 0) {
            for (int[] r : new int[][]{prevRect, nextRect}) {
                rr(ctx, r[0], r[1], r[2], r[3], 9, inside(r, mu, mv) ? C_CARD_HI : C_CHIP);
            }
        }

        if (section != 2) {
            rr(ctx, pageCard[0], pageCard[1], pageCard[2], pageCard[3], 9, C_CARD);
            if (genSliders != null) {
                for (Slider gs2 : genSliders) drawSliderShape(ctx, gs2);
            }
            if (toggleRect != null) {
                boolean on = GeneralSettings.crystal3d;
                rr(ctx, toggleRect[0], toggleRect[1], toggleRect[2], toggleRect[3], 7, on ? C_ACCENT : C_TRACK);
                rr(ctx, toggleRect[0] + (on ? toggleRect[2] - 13 : 1), toggleRect[1] + 1, 12, 12, 6, C_WHITE);
            }
            if (clanOpenRect != null) {
                rr(ctx, clanOpenRect[0], clanOpenRect[1], clanOpenRect[2], clanOpenRect[3], 11,
                        inside(clanOpenRect, mu, mv) ? C_ACCENT_HI : C_ACCENT);
                rr(ctx, clanCopyRect[0], clanCopyRect[1], clanCopyRect[2], clanCopyRect[3], 11,
                        inside(clanCopyRect, mu, mv) ? C_CARD_HI : C_CHIP);
            }
            return;
        }

        // Vorschau-Fläche + Regler
        rr(ctx, previewX, previewY, previewW, previewH, 9, C_CARD);
        if (satSlider != null) {
            drawSliderShape(ctx, satSlider);
            drawSliderShape(ctx, briSlider);
            rr(ctx, resetRect[0], resetRect[1], resetRect[2], resetRect[3], 8,
                    inside(resetRect, mu, mv) ? C_CARD_HI : C_CHIP);
        }
    }

    private double sliderStartU(Slider s) {
        return (s.getX() + 4) * gs / ui;
    }

    private double sliderEndU(Slider s) {
        return (s.getX() + s.getWidth() - 4) * gs / ui;
    }

    private void drawSliderShape(DrawContext ctx, Slider s) {
        double x0 = sliderStartU(s), x1 = sliderEndU(s);
        double cy = (s.getY() + s.getHeight() / 2.0) * gs / ui;
        double kx = x0 + s.t() * (x1 - x0);
        rr(ctx, x0, cy - 2, x1 - x0, 4, 2, C_TRACK);
        rr(ctx, x0, cy - 2, Math.max(1, kx - x0), 4, 2, C_ACCENT);
        rr(ctx, kx - 5, cy - 5, 10, 10, 5, C_WHITE);
    }

    private void drawContent(DrawContext ctx, SkinIndex.Category cat, double mu, double mv,
                             boolean hovering, String hoverValue, double t) {
        ctx.drawTextWithShadow(this.textRenderer,
                Text.literal("Glory Styles").formatted(Formatting.BOLD), px + 14, py + 16, C_ACCENT_HI);
        if (catHeadY >= 0) {
            ctx.drawTextWithShadow(this.textRenderer, Text.literal("KATEGORIEN"), px + 14, catHeadY, C_MUTED);
        }

        for (Item it : items) {
            int is = Math.min(14, it.h() - 4);
            if (it.icon() != null) {
                ctx.drawTexture(RenderPipelines.GUI_TEXTURED, it.icon(), it.x() + 6, it.y() + (it.h() - is) / 2,
                        0f, 0f, is, is, 16, 16, 16, 16);
            }
            ctx.drawTextWithShadow(this.textRenderer, Text.literal(it.label()), it.x() + 12 + is,
                    it.y() + (it.h() - 8) / 2, C_TEXT);
        }

        String name = this.client.player != null ? this.client.player.getName().getString() : "";
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(name), px + 14, py + ph - 33, C_TEXT);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal("Fabric 1.21.11"), px + 14, py + ph - 21, C_MUTED);
        String by = "by Zwetto";
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(by),
                px + pw - 14 - this.textRenderer.getWidth(by), py + ph - 14, C_MUTED);

        ctx.drawTextWithShadow(this.textRenderer,
                Text.literal(section == 2 ? cat.name() : MAIN_LABELS[section]).formatted(Formatting.BOLD),
                contentX, py + 18, C_TEXT);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("X"),
                closeRect[0] + closeRect[2] / 2, closeRect[1] + 6, C_TEXT);
        if (hasPending()) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Anwenden (" + pendingCount() + ")"),
                    applyRect[0] + applyRect[2] / 2, applyRect[1] + 7, C_WHITE);
        }

        for (Chip ch : chips) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(ch.label()),
                    ch.x() + ch.w() / 2, ch.y() + 5, C_TEXT);
        }

        for (Card c : cards) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(c.label()),
                    c.x() + c.w() / 2, c.y() + c.h() - LABEL_H + 5, C_TEXT);
            if (c.tex() != null) {
                ctx.drawTexture(RenderPipelines.GUI_TEXTURED, c.tex(),
                        c.x() + (c.w() - ICON) / 2, c.y() + 12, 0f, 0f, ICON, ICON, 16, 16, 16, 16);
            }
        }

        if (maxPage > 0) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("<"), prevRect[0] + 9, prevRect[1] + 5, C_TEXT);
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(">"), nextRect[0] + 9, nextRect[1] + 5, C_TEXT);
            ctx.drawTextWithShadow(this.textRenderer, Text.literal((page + 1) + " / " + (maxPage + 1)),
                    contentX + 50, navY + 5, C_MUTED);
        }

        if (section == 2) drawPreviewContent(ctx, cat, hovering, hoverValue, t);
        else drawInfoPage(ctx);
    }

    private void drawInfoPage(DrawContext ctx) {
        int x = pageCard[0] + 16;
        int y = pageCard[1] + 16;
        int w = pageCard[2] - 32;
        if (section == 0) {
            ctx.drawTextWithShadow(this.textRenderer, Text.literal("Glory Clan").formatted(Formatting.BOLD), x, y, C_ACCENT_HI);
            int ty = y + 16;
            for (net.minecraft.text.OrderedText line : this.textRenderer.wrapLines(
                    Text.literal("Trete dem Offiziellen Glory Clan von zHeinskii bei!"), w)) {
                ctx.drawTextWithShadow(this.textRenderer, line, x, ty, C_TEXT);
                ty += 11;
            }
            ty += 8;
            ctx.drawTextWithShadow(this.textRenderer, Text.literal("Discord Server:"), x, ty, C_MUTED);
            ctx.drawTextWithShadow(this.textRenderer, Text.literal(DISCORD_URL), x, ty + 12, C_ACCENT_HI);
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Discord öffnen"),
                    clanOpenRect[0] + clanOpenRect[2] / 2, clanOpenRect[1] + 7, C_WHITE);
            boolean copied = System.currentTimeMillis() < copiedUntil;
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(copied ? "Kopiert!" : "Link kopieren"),
                    clanCopyRect[0] + clanCopyRect[2] / 2, clanCopyRect[1] + 7, copied ? 0xFF6EE7A0 : C_TEXT);
        } else if (genSliders != null) {
            for (int i = 0; i < GEN_NAMES.length; i++) {
                int by = pageCard[1] + 16 + i * GEN_BLOCK;
                int x0 = (int) Math.round(sliderStartU(genSliders[i]));
                int x1 = (int) Math.round(sliderEndU(genSliders[i]));
                ctx.drawTextWithShadow(this.textRenderer, Text.literal(GEN_NAMES[i]).formatted(Formatting.BOLD), x0, by, C_TEXT);
                String val = genValue(i) + " %";
                ctx.drawTextWithShadow(this.textRenderer, Text.literal(val), x1 - this.textRenderer.getWidth(val), by, C_ACCENT_HI);
                int hx = x0 + this.textRenderer.getWidth(GEN_NAMES[i]) + 12;
                int room = x1 - this.textRenderer.getWidth(val) - 8 - hx;
                if (room > 20) {
                    ctx.drawTextWithShadow(this.textRenderer, Text.literal(this.textRenderer.trimToWidth(GEN_HINTS[i], room)),
                            hx, by, C_MUTED);
                }
            }
            if (toggleRect != null) {
                int ty = pageCard[1] + 16 + GEN_NAMES.length * GEN_BLOCK;
                int x0 = pageCard[0] + 16;
                ctx.drawTextWithShadow(this.textRenderer, Text.literal("3D Crystals").formatted(Formatting.BOLD), x0, ty, C_TEXT);
                String st = GeneralSettings.crystal3d ? "An" : "Aus";
                ctx.drawTextWithShadow(this.textRenderer, Text.literal(st),
                        toggleRect[0] - 6 - this.textRenderer.getWidth(st), ty, C_ACCENT_HI);
                ctx.drawTextWithShadow(this.textRenderer, Text.literal("End-Kristall als 3D-Item wie platziert. Lädt kurz neu."),
                        x0, ty + 18, C_MUTED);
            }
        }
    }

    // ----------------------------------------------------------------- Vorschau

    private Tex previewTex(SkinIndex.Category cat, String shown, int targetIdx, String slot) {
        if (targetIdx >= cat.targets().size()) return null;
        SkinIndex.Target tg = cat.targets().get(targetIdx);
        if (shown == null) return VanillaTextures.get(tg.path().replace("assets/minecraft/", ""));
        String res = "/assets/glorystyles/textures/skins/" + cat.id() + "/" + shown + tg.suffix() + ".png";
        return PreviewTextures.get(slot, res, effSat(cat.id()), effBri(cat.id()));
    }

    private static String lastPart(String value) {
        int i = value.lastIndexOf('/');
        return i >= 0 ? value.substring(i + 1) : value;
    }

    private void drawPreviewContent(DrawContext ctx, SkinIndex.Category cat, boolean hovering, String hoverValue, double t) {
        if (previewW < 100 || previewH < 100) return;
        int cx = previewX + previewW / 2;
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Vorschau"), cx, previewY + 9, C_MUTED);

        // Regler-Beschriftung
        if (satSlider != null) {
            drawSliderLabel(ctx, "Sättigung", satSlider, effSat(cat.id()), sliderTop);
            drawSliderLabel(ctx, "Helligkeit", briSlider, effBri(cat.id()), sliderTop + 24);
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Zurücksetzen"),
                    resetRect[0] + resetRect[2] / 2, resetRect[1] + 4, C_TEXT);
        }

        String selected = effSelected(cat.id()); // markiert, sonst angewendet
        String shown = hovering ? hoverValue : selected;
        String label = shown == null ? "Standard" : lastPart(shown);
        int top = previewY + 24;
        int bottom = previewBottom;
        int ch = bottom - top;
        int cw = previewW - 24;
        Matrix3x2fStack m = ctx.getMatrices();

        switch (cat.preview()) {
            case "player" -> {
                String applied = SkinConfig.get(cat.id());
                String sel = applied == null ? "Standard" : lastPart(applied);
                ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(sel), cx, bottom - 10, C_ACCENT_HI);
            }
            case "crystal" -> {
                Tex ent = previewTex(cat, shown, 1, "ent");
                Tex item = previewTex(cat, shown, 0, "item");
                double box = Math.min(cw, ch - 56);
                if (ent != null && box > 20) {
                    drawCrystal(ctx, ent, cx, top + (ch - 56) / 2.0 + 4, box / 3.7, t);
                }
                if (item != null) drawSpinningSprite(ctx, item, cx, bottom - 30, 26, t);
                ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(label), cx, bottom - 8,
                        hovering ? C_ACCENT_HI : C_TEXT);
            }
            case "cube" -> {
                Tex tex = previewTex(cat, shown, 0, "item");
                double size = Math.min(Math.min(cw, ch - 22), 96);
                if (tex != null && size > 20) drawCube(ctx, tex, cx, top + (ch - 18) / 2.0, size / 2.9, t);
                ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(label), cx, bottom - 8,
                        hovering ? C_ACCENT_HI : C_TEXT);
            }
            default -> {
                Tex tex = previewTex(cat, shown, 0, "item");
                int size = (int) Math.max(16, Math.min(Math.min(cw, ch - 24), 72));
                if (tex != null) drawSpinningSprite(ctx, tex, cx, top + (ch - 18) / 2.0, size, t);
                ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(label), cx, bottom - 8,
                        hovering ? C_ACCENT_HI : C_TEXT);
            }
        }
    }

    private void drawSliderLabel(DrawContext ctx, String name, Slider s, double factor, int y) {
        int x0 = (int) Math.round(sliderStartU(s));
        int x1 = (int) Math.round(sliderEndU(s));
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(name), x0, y, C_MUTED);
        String val = Math.round(factor * 100) + " %";
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(val), x1 - this.textRenderer.getWidth(val), y, C_TEXT);
    }

    /** Item, das sich ganz langsam in der Luft dreht (flaches Sprite mit Dicke, wie ein fallengelassenes Item). */
    private void drawSpinningSprite(DrawContext ctx, Tex tex, double cx, double cy, double size, double t) {
        double ang = t * 0.5;
        double cos = Math.cos(ang), sin = Math.sin(ang);
        double thick = size / 16.0 * 1.4;
        int layers = 8;
        double bob = Math.sin(t * 1.6) * 2.0;
        Matrix3x2fStack m = ctx.getMatrices();
        int half = (int) Math.round(size / 2);
        for (int k = 0; k < layers; k++) {
            int idx = cos >= 0 ? k : layers - 1 - k;
            double z = (idx / (double) (layers - 1) - 0.5) * thick;
            m.pushMatrix();
            m.translate((float) (cx + z * sin), (float) (cy + bob));
            m.scale((float) cos, 1f);
            drawTex(ctx, tex, -half, -half, half * 2, half * 2);
            m.popMatrix();
        }
    }

    // ------------------------------------------------------- 3D (Würfel/Crystal)

    private static double[] mul(double[] a, double[] b) {
        double[] r = new double[9];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                r[i * 3 + j] = a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j];
        return r;
    }

    private static double[] rotY(double a) {
        double c = Math.cos(a), s = Math.sin(a);
        return new double[]{c, 0, s, 0, 1, 0, -s, 0, c};
    }

    private static double[] rotX(double a) {
        double c = Math.cos(a), s = Math.sin(a);
        return new double[]{1, 0, 0, 0, c, -s, 0, s, c};
    }

    private static double[] rotAxis(double x, double y, double z, double a) {
        double c = Math.cos(a), s = Math.sin(a), k = 1 - c;
        return new double[]{
                c + x * x * k, x * y * k - z * s, x * z * k + y * s,
                y * x * k + z * s, c + y * y * k, y * z * k - x * s,
                z * x * k - y * s, z * y * k + x * s, c + z * z * k};
    }

    private static double[] apply(double[] m, double x, double y, double z) {
        return new double[]{
                m[0] * x + m[1] * y + m[2] * z,
                m[3] * x + m[4] * y + m[5] * z,
                m[6] * x + m[7] * y + m[8] * z};
    }

    // Fläche: Normale, Ursprung, U-Richtung (nach rechts), V-Richtung (nach unten) - von außen gesehen
    private static final double[][] FACES = {
            {0, 0, 1, -1, 1, 1, 2, 0, 0, 0, -2, 0},   // vorne (+z)
            {0, 0, -1, 1, 1, -1, -2, 0, 0, 0, -2, 0}, // hinten
            {1, 0, 0, 1, 1, 1, 0, 0, -2, 0, -2, 0},   // rechts
            {-1, 0, 0, -1, 1, -1, 0, 0, 2, 0, -2, 0}, // links
            {0, 1, 0, -1, 1, -1, 2, 0, 0, 0, 0, 2},   // oben
            {0, -1, 0, -1, -1, 1, 2, 0, 0, 0, 0, -2}  // unten
    };
    // Position der Flächen in der Crystal-Textur (Vanilla-Einheiten, Würfel 8x8x8)
    private static final int[][] FACE_UV = {{24, 8}, {8, 8}, {16, 8}, {0, 8}, {8, 0}, {16, 0}};

    private void addCube(List<FaceDraw> out, double[] r, double half, double cx, double cy, double s,
                         Tex tex, int uo, int vo, boolean crystalUv, boolean cullBack) {
        for (int i = 0; i < 6; i++) {
            double[] f = FACES[i];
            double[] n = apply(r, f[0], f[1], f[2]);
            if (cullBack && n[2] <= 0) continue;
            double[] o = apply(r, f[3] * half, f[4] * half, f[5] * half);
            double[] u = apply(r, f[6] * half, f[7] * half, f[8] * half);
            double[] v = apply(r, f[9] * half, f[10] * half, f[11] * half);
            FaceDraw d = new FaceDraw();
            d.tex = tex;
            d.ox = cx + o[0] * s;
            d.oy = cy - o[1] * s;
            d.ux = u[0] * s;
            d.uy = -u[1] * s;
            d.vx = v[0] * s;
            d.vy = -v[1] * s;
            d.depth = o[2] + (u[2] + v[2]) / 2.0;
            if (crystalUv) {
                int k = Math.max(1, tex.w() / 64);
                d.u = (uo + FACE_UV[i][0]) * k;
                d.v = (vo + FACE_UV[i][1]) * k;
                d.rw = 8 * k;
                d.rh = 8 * k;
            } else {
                d.u = 0;
                d.v = 0;
                d.rw = tex.w();
                d.rh = tex.h();
            }
            out.add(d);
        }
    }

    private void drawFaces(DrawContext ctx, List<FaceDraw> faces) {
        faces.sort(Comparator.comparingDouble(f -> f.depth));
        Matrix3x2fStack m = ctx.getMatrices();
        for (FaceDraw d : faces) {
            m.pushMatrix();
            m.translate((float) d.ox, (float) d.oy);
            m.mul(new Matrix3x2f((float) (d.ux / d.rw), (float) (d.uy / d.rw),
                    (float) (d.vx / d.rh), (float) (d.vy / d.rh), 0f, 0f));
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, d.tex.id(), 0, 0, d.u, d.v, d.rw, d.rh, d.rw, d.rh,
                    d.tex.w(), d.tex.h());
            m.popMatrix();
        }
    }

    /** Block (Obsidian usw.) als sich langsam drehender Würfel. */
    private void drawCube(DrawContext ctx, Tex tex, double cx, double cy, double s, double t) {
        double[] r = mul(rotX(0.5), rotY(t * 0.5));
        double bob = Math.sin(t * 1.6) * 2.0;
        List<FaceDraw> faces = new ArrayList<>();
        addCube(faces, r, 1.0, cx, cy + bob, s, tex, 0, 0, false, true);
        drawFaces(ctx, faces);
    }

    /** End Crystal wie im Spiel: ineinander gedrehte Würfel, schwebend und langsam drehend. */
    private void drawCrystal(DrawContext ctx, Tex ent, double cx, double cy, double s, double t) {
        double spin = t * 0.6;
        double a = Math.sqrt(0.5);
        double[] tilt = rotAxis(a, 0, a, Math.toRadians(60));
        double[] step = mul(tilt, rotY(spin));
        double[] m1 = step;
        double[] m2 = mul(m1, step);
        double[] m3 = mul(m2, step);
        double[] cam = rotX(0.4);
        double bob = Math.sin(t * 1.6) * 0.3 * s;
        List<FaceDraw> faces = new ArrayList<>();
        addCube(faces, mul(cam, m1), 1.0, cx, cy + bob, s, ent, 0, 0, true, false);
        addCube(faces, mul(cam, m2), 0.875, cx, cy + bob, s, ent, 0, 0, true, false);
        addCube(faces, mul(cam, m3), 0.7656, cx, cy + bob, s, ent, 32, 0, true, false);
        drawFaces(ctx, faces);
    }

    // ------------------------------------------------------------- Spieler (Glint)

    private void drawPlayer(DrawContext ctx, int mouseX, int mouseY) {
        if (previewW < 100 || previewH < 100) return;
        LivingEntity e = getPreviewPlayer();
        int x1 = toGui(previewX + 6), x2 = toGui(previewX + previewW - 6);
        int y1 = toGui(previewY + 26), y2 = toGui(previewBottom - 14);
        if (e == null || y2 - y1 < 30) return;
        int size = Math.max(20, Math.min(60, (y2 - y1) / 2 - 4));
        InventoryScreen.drawEntity(ctx, x1, y1, x2, y2, size, 0.0625f, mouseX, mouseY, e);
    }

    /** Baut (einmalig pro Welt) einen Spieler mit verzauberter Diamant-Rüstung und Schwert. */
    private LivingEntity getPreviewPlayer() {
        if (this.client == null || this.client.world == null || this.client.player == null) return null;
        if (previewPlayer == null || previewWorld != this.client.world) {
            OtherClientPlayerEntity e = new OtherClientPlayerEntity(this.client.world, this.client.player.getGameProfile());
            equip(e, EquipmentSlot.HEAD, Items.DIAMOND_HELMET);
            equip(e, EquipmentSlot.CHEST, Items.DIAMOND_CHESTPLATE);
            equip(e, EquipmentSlot.LEGS, Items.DIAMOND_LEGGINGS);
            equip(e, EquipmentSlot.FEET, Items.DIAMOND_BOOTS);
            equip(e, EquipmentSlot.MAINHAND, Items.DIAMOND_SWORD);
            previewPlayer = e;
            previewWorld = this.client.world;
        }
        return previewPlayer;
    }

    private static void equip(LivingEntity e, EquipmentSlot slot, net.minecraft.item.Item item) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        e.equipStack(slot, stack);
    }
}
